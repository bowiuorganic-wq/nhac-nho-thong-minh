Đặt các file nhạc chuông hợp lệ của bạn vào thư mục này để nghe thử trên Chrome:
- c1_champions.wav
- tiktok_1.wav
- tiktok_2.wav
- tiktok_3.wav
- tiktok_4.wav
- tiktok_5.wav

Lưu ý: App không đính kèm sẵn nhạc Champions League/C1 hoặc nhạc TikTok vì đây thường là nhạc có bản quyền. Hãy chỉ dùng file bạn có quyền sử dụng.
